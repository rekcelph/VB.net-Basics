#include <iostream>

using namespace std;

int permission() {
    cout << "Enter the number of days you want to rent: ";
    int op;
    cin >> op;
    return op;
}

int main() {
    char ch;
    int rent = 0;
    cout << "Enter the type of vehicle you want to rent (a: Car, b: LT, c: WaterMotor, d: Tent): ";
    cin >> ch;

    cout << "Enter the rental price per day: ";
    int rentalPrice;
    cin >> rentalPrice;

    int op = permission();
    switch (ch) {
        case 'a':
            rent = rentalPrice * op + 500; // Assuming there's a base rental fee of 500 for cars
            break;
        case 'b':
        case 'c':
            rent = rentalPrice * op;
            break;
        case 'd':
            rent = rentalPrice * op + 3000; // Assuming there's a base rental fee of 3000 for tents
            break;
        default:
            cout << "Invalid option!";
            return 1; // Indicate error
    }

    cout << "You should pay " << rent << " in total." << endl;
    return 0; // Indicate successful execution
}
