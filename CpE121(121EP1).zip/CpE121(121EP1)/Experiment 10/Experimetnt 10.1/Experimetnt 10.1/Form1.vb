﻿Imports System.Diagnostics.Eventing.Reader
Imports System.IO
Imports Microsoft.VisualBasic.Devices

Public Class Form1

    Private Sub lbl_add12_MouseHover(sender As Object, e As EventArgs) Handles lbl_add12.MouseHover
        lbl_add12.BackColor = Color.LightPink
        num1 = Val(tb_num1.Text)
        num2 = Val(tb_num2.Text)
        num3 = Val(tb_num3.Text)
        ans = num1 + num2
        lbl_ans.Text = ans
    End Sub

    Private Sub lbl_2and3_MouseHover(sender As Object, e As EventArgs) Handles lbl_2and3.MouseHover
        lbl_2and3.BackColor = Color.LightBlue
        num1 = Val(tb_num1.Text)
        num2 = Val(tb_num2.Text)
        num3 = Val(tb_num3.Text)
        ans = num2 + num3
        lbl_ans.Text = ans
    End Sub

    Private Sub lbl_1and3_MouseHover(sender As Object, e As EventArgs) Handles lbl_1and3.MouseHover
        lbl_1and3.BackColor = Color.LightGreen
        num1 = Val(tb_num1.Text)
        num2 = Val(tb_num2.Text)
        num3 = Val(tb_num3.Text)
        ans = num1 + num3
        lbl_ans.Text = ans
    End Sub

    Private Sub lbl_add12_MouseLeave(sender As Object, e As EventArgs) Handles lbl_add12.MouseLeave
        lbl_add12.BackColor = Color.White
        lbl_ans.Text = 0
    End Sub

    Private Sub lbl_2and3_MouseLeave(sender As Object, e As EventArgs) Handles lbl_2and3.MouseLeave
        lbl_2and3.BackColor = Color.White
        lbl_ans.Text = 0
    End Sub

    Private Sub lbl_1and3_MouseLeave(sender As Object, e As EventArgs) Handles lbl_1and3.MouseLeave
        lbl_1and3.BackColor = Color.White
        lbl_ans.Text = 0
    End Sub





    Private Sub lb_sub1_MouseLeave(sender As Object, e As EventArgs) Handles lb_sub1.MouseLeave
        lb_sub1.BackColor = Color.White
        lbl_ans.Text = 0
    End Sub

    Private Sub lb_sub2_MouseHover(sender As Object, e As EventArgs) Handles lb_sub2.MouseHover
        lb_sub2.BackColor = Color.LightSeaGreen
        num1 = Val(tb_num1.Text)
        num2 = Val(tb_num2.Text)
        num3 = Val(tb_num3.Text)
        ans = num2 - num3
        lbl_ans.Text = ans
    End Sub

    Private Sub lb_sub2_MouseLeave(sender As Object, e As EventArgs) Handles lb_sub2.MouseLeave
        lb_sub2.BackColor = Color.White
        lbl_ans.Text = 0
    End Sub

    Private Sub lb_sub3_MouseHover(sender As Object, e As EventArgs) Handles lb_sub3.MouseHover
        lb_sub3.BackColor = Color.LightYellow
        num1 = Val(tb_num1.Text)
        num2 = Val(tb_num2.Text)
        num3 = Val(tb_num3.Text)
        ans = num1 - num3
        lbl_ans.Text = ans
    End Sub

    Private Sub lb_sub3_MouseLeave(sender As Object, e As EventArgs) Handles lb_sub3.MouseLeave
        lb_sub3.BackColor = Color.White
        lbl_ans.Text = 0
    End Sub

    Private Sub lb_sub1_MouseHover(sender As Object, e As EventArgs) Handles lb_sub1.MouseHover
        lb_sub1.BackColor = Color.LightCyan
        num1 = Val(tb_num1.Text)
        num2 = Val(tb_num2.Text)
        num3 = Val(tb_num3.Text)
        ans = num1 - num2
        lbl_ans.Text = ans
    End Sub

    Private Sub lb_high_MouseHover(sender As Object, e As EventArgs) Handles lb_high.MouseHover
        lb_high.BackColor = Color.LightSteelBlue
        num1 = Val(tb_num1.Text)
        num2 = Val(tb_num2.Text)
        num3 = Val(tb_num3.Text)

        If num1 > num2 And num1 > num3 Then
            lbl_ans.Text = num1 & " " & "is the highest"

        ElseIf num2 > num1 And num2 > num3 Then
            lbl_ans.Text = num2 & " " & "is the highest"
        ElseIf num3 > num1 And num3 > num2 Then
            lbl_ans.Text = num3 & " " & "is the highest"
        End If
    End Sub

    Private Sub lb_high_MouseLeave(sender As Object, e As EventArgs) Handles lb_high.MouseLeave
        lb_high.BackColor = Color.White
        lbl_ans.Text = 0

    End Sub

    Private Sub lb_low_MouseHover(sender As Object, e As EventArgs) Handles lb_low.MouseHover
        lb_high.BackColor = Color.LightSeaGreen
        num1 = Val(tb_num1.Text)
        num2 = Val(tb_num2.Text)
        num3 = Val(tb_num3.Text)

        If num1 < num2 And num1 < num3 Then
            lbl_ans.Text = num1 & " " & "is the lowest"

        ElseIf num2 < num1 And num2 < num3 Then
            lbl_ans.Text = num2 & " " & "is the lowest"
        ElseIf num3 < num1 And num3 < num2 Then
            lbl_ans.Text = num3 & " " & "is the lowest"
        End If
    End Sub

    Private Sub lb_low_MouseLeave(sender As Object, e As EventArgs) Handles lb_low.MouseLeave
        lb_low.BackColor = Color.Blue
        lbl_ans.Text = 0
    End Sub
End Class
