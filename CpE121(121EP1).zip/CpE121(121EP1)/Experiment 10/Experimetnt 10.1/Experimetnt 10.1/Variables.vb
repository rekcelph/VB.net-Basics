﻿Module Variables

    Public num1, num2, num3, ans As Integer
    Public x1, y1, x2, y2 As Integer
End Module
