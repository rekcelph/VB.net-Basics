﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        tb_num1 = New TextBox()
        tb_num2 = New TextBox()
        tb_num3 = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        lbl_ans = New Label()
        Label5 = New Label()
        lbl_add12 = New Label()
        lbl_2and3 = New Label()
        lbl_1and3 = New Label()
        lb_sub1 = New Label()
        lb_sub2 = New Label()
        lb_sub3 = New Label()
        lb_high = New Label()
        lb_low = New Label()
        SuspendLayout()
        ' 
        ' tb_num1
        ' 
        tb_num1.Location = New Point(103, 48)
        tb_num1.Name = "tb_num1"
        tb_num1.Size = New Size(100, 23)
        tb_num1.TabIndex = 0
        ' 
        ' tb_num2
        ' 
        tb_num2.Location = New Point(103, 109)
        tb_num2.Name = "tb_num2"
        tb_num2.Size = New Size(100, 23)
        tb_num2.TabIndex = 1
        ' 
        ' tb_num3
        ' 
        tb_num3.Location = New Point(103, 168)
        tb_num3.Name = "tb_num3"
        tb_num3.Size = New Size(100, 23)
        tb_num3.TabIndex = 2
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(34, 51)
        Label1.Name = "Label1"
        Label1.Size = New Size(63, 15)
        Label1.TabIndex = 3
        Label1.Text = "Number 1:"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(34, 109)
        Label2.Name = "Label2"
        Label2.Size = New Size(63, 15)
        Label2.TabIndex = 4
        Label2.Text = "Number 2:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(34, 168)
        Label3.Name = "Label3"
        Label3.Size = New Size(63, 15)
        Label3.TabIndex = 5
        Label3.Text = "Number 3:"
        ' 
        ' lbl_ans
        ' 
        lbl_ans.AutoSize = True
        lbl_ans.Font = New Font("Verdana", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lbl_ans.Location = New Point(452, 109)
        lbl_ans.Name = "lbl_ans"
        lbl_ans.Size = New Size(22, 23)
        lbl_ans.TabIndex = 6
        lbl_ans.Text = "0"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(71, 247)
        Label5.Name = "Label5"
        Label5.RightToLeft = RightToLeft.No
        Label5.Size = New Size(180, 15)
        Label5.TabIndex = 7
        Label5.Text = "Point your mouse of your choice"
        ' 
        ' lbl_add12
        ' 
        lbl_add12.AutoSize = True
        lbl_add12.Location = New Point(71, 308)
        lbl_add12.Name = "lbl_add12"
        lbl_add12.Size = New Size(70, 15)
        lbl_add12.TabIndex = 8
        lbl_add12.Text = "Add 1 and 2"
        ' 
        ' lbl_2and3
        ' 
        lbl_2and3.AutoSize = True
        lbl_2and3.Location = New Point(71, 353)
        lbl_2and3.Name = "lbl_2and3"
        lbl_2and3.Size = New Size(70, 15)
        lbl_2and3.TabIndex = 9
        lbl_2and3.Text = "Add 2 and 3"
        ' 
        ' lbl_1and3
        ' 
        lbl_1and3.AutoSize = True
        lbl_1and3.Location = New Point(71, 401)
        lbl_1and3.Name = "lbl_1and3"
        lbl_1and3.Size = New Size(70, 15)
        lbl_1and3.TabIndex = 10
        lbl_1and3.Text = "Add 1 and 3"
        ' 
        ' lb_sub1
        ' 
        lb_sub1.AutoSize = True
        lb_sub1.Location = New Point(228, 308)
        lb_sub1.Name = "lb_sub1"
        lb_sub1.Size = New Size(92, 15)
        lb_sub1.TabIndex = 11
        lb_sub1.Text = "Subtract 1 and 2"
        ' 
        ' lb_sub2
        ' 
        lb_sub2.AutoSize = True
        lb_sub2.Location = New Point(228, 353)
        lb_sub2.Name = "lb_sub2"
        lb_sub2.Size = New Size(92, 15)
        lb_sub2.TabIndex = 12
        lb_sub2.Text = "Subtract 2 and 3"
        ' 
        ' lb_sub3
        ' 
        lb_sub3.AutoSize = True
        lb_sub3.Location = New Point(228, 401)
        lb_sub3.Name = "lb_sub3"
        lb_sub3.Size = New Size(92, 15)
        lb_sub3.TabIndex = 13
        lb_sub3.Text = "Subtract 1 and 3"
        ' 
        ' lb_high
        ' 
        lb_high.AutoSize = True
        lb_high.Location = New Point(426, 327)
        lb_high.Name = "lb_high"
        lb_high.Size = New Size(48, 15)
        lb_high.TabIndex = 14
        lb_high.Text = "Highest"
        ' 
        ' lb_low
        ' 
        lb_low.AutoSize = True
        lb_low.Location = New Point(426, 353)
        lb_low.Name = "lb_low"
        lb_low.Size = New Size(44, 15)
        lb_low.TabIndex = 15
        lb_low.Text = "Lowest"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(lb_low)
        Controls.Add(lb_high)
        Controls.Add(lb_sub3)
        Controls.Add(lb_sub2)
        Controls.Add(lb_sub1)
        Controls.Add(lbl_1and3)
        Controls.Add(lbl_2and3)
        Controls.Add(lbl_add12)
        Controls.Add(Label5)
        Controls.Add(lbl_ans)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(tb_num3)
        Controls.Add(tb_num2)
        Controls.Add(tb_num1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents tb_num1 As TextBox
    Friend WithEvents tb_num2 As TextBox
    Friend WithEvents tb_num3 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lbl_ans As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lbl_add12 As Label
    Friend WithEvents lbl_2and3 As Label
    Friend WithEvents lbl_1and3 As Label
    Friend WithEvents lb_sub1 As Label
    Friend WithEvents lb_sub2 As Label
    Friend WithEvents lb_sub3 As Label
    Friend WithEvents lb_high As Label
    Friend WithEvents lb_low As Label

End Class
