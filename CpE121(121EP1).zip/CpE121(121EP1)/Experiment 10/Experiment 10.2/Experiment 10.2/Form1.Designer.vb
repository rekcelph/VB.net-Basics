﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        num1 = New TextBox()
        num2 = New TextBox()
        Label1 = New Label()
        Label2 = New Label()
        DivisibleNumbers = New ListBox()
        btn_clear = New Button()
        SuspendLayout()
        ' 
        ' num1
        ' 
        num1.Location = New Point(213, 124)
        num1.Name = "num1"
        num1.Size = New Size(100, 23)
        num1.TabIndex = 0
        ' 
        ' num2
        ' 
        num2.Location = New Point(499, 124)
        num2.Name = "num2"
        num2.Size = New Size(100, 23)
        num2.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(225, 106)
        Label1.Name = "Label1"
        Label1.Size = New Size(77, 15)
        Label1.TabIndex = 2
        Label1.Text = "ENTER Num1"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(511, 106)
        Label2.Name = "Label2"
        Label2.Size = New Size(77, 15)
        Label2.TabIndex = 3
        Label2.Text = "ENTER Num2"
        ' 
        ' DivisibleNumbers
        ' 
        DivisibleNumbers.FormattingEnabled = True
        DivisibleNumbers.ItemHeight = 15
        DivisibleNumbers.Location = New Point(239, 232)
        DivisibleNumbers.Name = "DivisibleNumbers"
        DivisibleNumbers.Size = New Size(304, 109)
        DivisibleNumbers.TabIndex = 4
        ' 
        ' btn_clear
        ' 
        btn_clear.Location = New Point(374, 161)
        btn_clear.Name = "btn_clear"
        btn_clear.Size = New Size(72, 28)
        btn_clear.TabIndex = 6
        btn_clear.Text = "Clear"
        btn_clear.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(btn_clear)
        Controls.Add(DivisibleNumbers)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(num2)
        Controls.Add(num1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents num1 As TextBox
    Friend WithEvents num2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents DivisibleNumbers As ListBox
    Friend WithEvents btn_clear As Button

End Class
