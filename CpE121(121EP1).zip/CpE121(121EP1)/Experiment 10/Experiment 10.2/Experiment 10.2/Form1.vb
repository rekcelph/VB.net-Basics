﻿Imports System.Diagnostics.CodeAnalysis

Public Class Form1
    Private Sub Update(sender As Object, e As EventArgs) Handles num1.TextChanged, num2.TextChanged
        numb1 = Val(num1.Text)
        numb2 = Val(num2.Text)
        If numb1 Mod 2 = 0 Then
            DivisibleNumbers.Items.Add(numb1 & " is Divisible by " & 2)
        Else
            DivisibleNumbers.Items.Add(numb1 & " is not Divisible by " & 2)
        End If
        If numb1 Mod 3 = 0 Then
            DivisibleNumbers.Items.Add(numb1 & " is Divisible by " & 3)
        Else
            DivisibleNumbers.Items.Add(numb1 & " is not Divisible by " & 3)
        End If

        If numb1 Mod 5 = 0 Then
            DivisibleNumbers.Items.Add(numb1 & " is Divisible by " & 5)
        Else
            DivisibleNumbers.Items.Add(numb1 & " is not Divisible by " & 5)

        End If

        If numb1 Mod 7 = 0 Then
            DivisibleNumbers.Items.Add(numb1 & " is Divisible by " & 7)
        Else
            DivisibleNumbers.Items.Add(numb1 & " is Divisible by " & 7)
        End If

        If numb2 Mod 2 = 0 Then
            DivisibleNumbers.Items.Add(numb2 & " is Divisible by " & 2)
        Else
            DivisibleNumbers.Items.Add(numb2 & " is not Divisible by " & 2)

        End If
        If numb2 Mod 3 = 0 Then
            DivisibleNumbers.Items.Add(numb2 & " is Divisible by " & 3)
        Else
            DivisibleNumbers.Items.Add(numb2 & " is Divisible by " & 3)
        End If
        If numb2 Mod 5 = 0 Then
            DivisibleNumbers.Items.Add(numb2 & " is Divisible by " & 5)
        Else
            DivisibleNumbers.Items.Add(numb2 & " is not Divisible by " & 3)
        End If

        If numb2 Mod 7 = 0 Then
            DivisibleNumbers.Items.Add(numb2 & " is Divisible by " & 7)
        Else
            DivisibleNumbers.Items.Add(numb2 & " is not Divisible by " & 7)
        End If

        If num1.Text = "" Or num2.Text = "" Then
            DivisibleNumbers.Items.Clear()
        End If


    End Sub

    Private Sub num1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles num1.KeyPress
        If (Not Char.IsNumber(e.KeyChar)) Then
            MsgBox("Please Put numbers only")

        End If
    End Sub

    Private Sub num2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles num2.KeyPress
        If (Not Char.IsNumber(e.KeyChar)) Then
            MsgBox("Please Put numbers only")


        End If
    End Sub

    Private Sub btn_clear_Click(sender As Object, e As EventArgs) Handles btn_clear.Click
        DivisibleNumbers.Items.Clear()
        num1.Clear()
        num2.Clear()
    End Sub
End Class
