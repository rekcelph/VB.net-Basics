﻿Module variables
    Public numb1, numb2, ans As Integer
End Module
