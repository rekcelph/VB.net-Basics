#include <iostream>
#include <iomanip>
#include <cmath>
#define PI 3.141592653589793

using namespace std;

class pythagorean {
    public:
        double sideA;
        double sideB;
        double sideC;
        pythagorean(double a, double b, double c)
        {
            sideA= a;
            sideB= b;
            sideC= c;
        }

        void calculateSides() {
            double AngleA = atan2 (sideB,sideA) * (180 / PI); 
            double AngleB = atan2(sideB,sideA) * (180 / PI); 
            double AngleC = 90.0;


            cout << "AngleA: " << fixed << setprecision(2) << AngleA <<"degrees" << endl;
            cout << "AngleB: " << fixed << setprecision(2) << AngleB <<"degrees" << endl;
            cout << "AngleC: " << AngleC << "degrees" << endl;

            cout <<"\nThis are the sides" << endl;
            cout << "Side A: " << fixed << setprecision(2) << sideA << endl;
            cout << "Side B: " << fixed << setprecision(2) << sideB << endl;
            cout << "Side C: " << fixed << setprecision(2) << sideC << endl;
        }
};

int main() {
    double side1, side2, side3;

    cout << "Enter the lengths of the two sides of the right triangle" << endl;
    cout << "Enter Side A: " ;
    cin >> side1;
    cout << "Enter Side B: " ;
    cin >> side2;

    side3 = sqrt(side1 * side1 + side2 * side2);

    pythagorean Pytha(side1, side2, side3);
    Pytha.calculateSides();

    return 0;
}