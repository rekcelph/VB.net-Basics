#include <iostream>
#include <string>
using namespace std;

class BioDATA  {
public:
    string Name;
    int Age;
    string ContactNumber;

    BioDATA(string name, int age, string contactNumber) {
        Name = name;
        Age = age;
        ContactNumber = contactNumber;
    }

    void displayInformation(string choice) {
        cout << choice << "'s Info:" << endl;
        cout << "Name: " << Name << endl;
        cout << "Contact No. : " << ContactNumber << endl;
        cout << "Age: " << Age << " years old" << endl;
    }
};

int main() {
    char choice = 'y';

    while (choice == 'y' || choice == 'Y') {
        string name;
        string contactNumber;
        int age;

        cout << "Please press Enter to input student Data... ";

        cin.ignore();

        cout << "Enter your Name: ";
        getline(cin, name);

        cout << "Enter your Age: ";
        cin >> age;
        cin.ignore();

        cout << "Enter your Contact No.: ";
        getline(cin, contactNumber);

        cout << "Hello " << name << endl;
        cout << "Your " << age << " year/s old" << endl;
        cout << "I'll call you with this number " << contactNumber << endl;

        BioDATA student(name, age, contactNumber);
        student.displayInformation("Student");

        cout << "Do you want to enter another student's data? (y/n): ";
        cin >> choice;
        cin.ignore();
    }

    return 0;
}