#include <iostream>
#include <string>
#include <windows.h>
#include <stdio.h>

using namespace std;

#define RED 12
#define BLUE 9
#define GREEN 10
#define WHITE 15

void changeColour(int colour) {
    HANDLE hConsole;
    hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, colour);
}

void showloadingscreen() {
    string closed = "MADE BY REKCEL", open = "Made by REKCEL";
    int colour[] = { RED, BLUE, GREEN };

    cout << "Closed";

    for (int i = 0; i < 3; i++) {
        Sleep(1000);

        system("cls");  
        changeColour(colour[i]);

        cout << "open";

        Sleep(1000);

        system("cls");
        changeColour(WHITE);

        cout << "closed";
    }
    system("cls");
    changeColour(WHITE);
}

void showBlinkingLights() {
    changeColour(RED);
    cout << "EXPERIMENT";
    Sleep(1000);

    changeColour(GREEN);
    cout << " 5 BY:";
    Sleep(1000);

    changeColour(BLUE);
    cout << "REKCEL ENDENCIA";
    Sleep(1000);

    changeColour(WHITE);
}

// Base class
class Personality {
public:
    void inputPersonality() {
        cout << "\nWhat type of a person are you?" << endl;
        cout << "\nType [I] if Introverted and [E] if Extroverted" << endl;
        cout << "\nEnter your choice: " << endl;
        cin >> personality;
        while (!(personality == "i" || personality == "I" || personality == "e" || personality == "E")) {
        cout << "Invalid input! Please enter either 'I' for Introverted or 'E' for Extroverted: ";
        cin >> personality;
        }
    }

    void printPersonality() {
        cout << "\n\nPersonality: " << personality << endl;
    }

private:
    string personality;
};

// Base class
class Biodata {
public:
    void inputBiodata() {
        cout << "\n\n\t\tInput Biodata" << endl;
        cout << "\nEnter your First name: ";
        cin >> name;
        cout << "Enter your Middle name: ";
        cin >> middleName;
        cout << "Enter your Last name: ";
        cin >> lastName;
        cout << "Enter your age: ";
        cin >> age;
        cout << "Enter your course: ";
        cin >> course;
        cout << "Enter your section: ";
        cin >> section;
    }

    void printBiodata() {
        cout << "\n\t\t[Biodata]" << endl;
        cout << "\n\nName: " << lastName << ", " << name << ", " << middleName << endl;
        cout << "Age: " << age << endl;
        cout << "Course: " << course <<" "<< section << endl;
    }

private:
    string name;
    string middleName;
    string lastName;
    int age;
    string course;
    string section;
};

// Base class
class Characteristic {
public:
    void inputCharacteristic() {
        cout << "\n\n\t    Input Characteristic" << endl;
        cout << "\n\nEnter your height (in inches): ";
        cin >> height;
        cout << "Enter your weight (Kg): ";
        cin >> weight;
    }

    void printCharacteristic() {
        cout << "\n\n\t    [Characteristic]"<< endl;
        cout << "Height: " << height << endl;
        cout << "Weight: " << weight << "Kg" << endl;
    }

private:
    double height;
    double weight;
};

// Derived class 
class Informations : public Personality, public Biodata, public Characteristic {
public:

    void executeAllFunctions() {
        inputPersonality();
        inputBiodata();
        inputCharacteristic();
        printPersonality();
        printBiodata();
        printCharacteristic();
    }
};

int main() {
    char choice;
    do{
    Informations info;

    cout << "\t\t\t[This program will know who you are]\n" << endl;

    cout << "\n";
    showloadingscreen();
    showBlinkingLights();

    cout << "\n";

    info.executeAllFunctions();
    cout << "Do you want to run this program again?? [Y/N] " << endl;
    cin >> choice;
    
    }while(choice == 'y' || choice == 'Y');
    

    return 0;
}
