// Inside the inputBiodata function
cout << "\nEnter your First name: ";
getline(cin, name);

cout << "Enter your Middle name: ";
getline(cin, middleName);

cout << "Enter your Last name: ";
getline(cin, lastName);

cout << "Enter your age: ";
cin >> age;

cout << "Enter your course: ";
getline(cin, course);

cout << "Enter your section: ";
getline(cin, section);

// Inside the inputPersonality function
cout << "\nEnter your personality description: ";
getline(cin, personality);
