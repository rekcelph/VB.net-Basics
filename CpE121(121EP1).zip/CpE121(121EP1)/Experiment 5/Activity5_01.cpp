/*Create a C++ program with a Parent class (Formula). Class (Fomula) has an attributes
named (Base and Height). Inside the function/method, the program will ask the user to enter the
height and base of an object. Create another class named Rectangle and Triangle that will inherit
the class Formula. Rectangle class will have a function that will compute for the area of the
rectangle and Triangle class will have a function that will compute for the area of the triangle.
Lastly, the program will display the Area of the Triangle and Rectangle with the given value*/

#include <iostream>
using namespace std;

class Formula {
public:
    float base, height;

    void getData() {
        cout << "Enter the base: ";
        cin >> base;
        cout << "Enter the height: ";
        cin >> height;
    }
};

class Rectangle : public Formula {
public:
    double area() {
        return base * height;
    }
};

class Triangle : public Formula {
public:
    double area() {
        return 0.5 * base * height;
    }
};

int main() {
    Rectangle rectangle;
    Triangle triangle;

    rectangle.getData();
    cout << "Area of the rectangle: " << rectangle.area() << endl;

    triangle.getData();
    cout << "Area of the triangle: " << triangle.area() << endl;

    return 0;
}


