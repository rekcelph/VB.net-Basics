#include <iostream>
using namespace std;

class fruits {
public:

void apple()
{
    cout <<"The Apple is red"<<endl;
}
void orange()
{
    cout <<"The Orange is riped"<<endl;
}
void mango()
{
    cout <<"The Mango is delicious"<<endl;
}

};

class vegetables {
public:

void Tomatoes()
{
    cout <<"The Tomatoes are red"<<endl;
}
void Onion()
{
    cout <<"The Onions are tasty"<<endl;
}
void Garlic()
{
    cout <<"The garlics are white"<<endl;
}

};
int main()
{
cout <<"Fruits:"<<endl;
    fruits a;
    a.apple();
    fruits b;
    b.orange();
    fruits c;
    c.mango();
cout <<"\nVegetables:"<<endl;
    vegetables x;
    x.Tomatoes();
    vegetables y;
    y.Onion();
    vegetables i;
    i.Garlic();
    
    return 0;

}