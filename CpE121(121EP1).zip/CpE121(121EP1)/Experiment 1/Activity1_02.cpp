#include <iostream>
using namespace std;

class box{
public:
    double length;
    double height;
    double breadth;


};
int main()
{
    box box1;
    box box2;
double volume1, volume2;

cout << "Enter Box1 lenght: " << endl;
cin>> box1.length;
cout << "Enter Box1 height: " << endl;
cin >> box1.height;
cout << "Enter Box1 breadth: " << endl;
cin>> box1.breadth;

cout << "\nEnter Box2 lenght: " << endl;
cin>> box2.length;
cout << "Enter Box2 height: " << endl;
cin >> box2.height;
cout << "Enter Box2 breadth: " << endl;
cin>> box2.breadth;

volume1 = box1.height * box1.length * box1.breadth;
cout << "volume of box : " << volume1 << endl;
volume2 = box2.height * box2.length * box2.breadth;
cout << "volume of box : " << volume2 << endl;

if (volume1 > volume2)
{
    cout << "Volume1 is less than Volume2 "<< endl;
}
else if (volume1 < volume2)
{
    cout << "Volume1 is greater than Volume2 "<< endl;
}
else
{
    cout << "Volume 1 is equal to volume 2" << endl;
}
return 0;
}