﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Rb1 = New RadioButton()
        Rb2 = New RadioButton()
        Rb3 = New RadioButton()
        GroupBox1 = New GroupBox()
        Label1 = New Label()
        Title1 = New Label()
        Title2 = New Label()
        title3 = New Label()
        title4 = New Label()
        title5 = New Label()
        Num1 = New TextBox()
        Num2 = New TextBox()
        Num3 = New TextBox()
        Num4 = New TextBox()
        Num5 = New TextBox()
        Label2 = New Label()
        Button1 = New Button()
        Button2 = New Button()
        Button3 = New Button()
        Label3 = New Label()
        Grade = New Label()
        Label4 = New Label()
        GroupBox1.SuspendLayout()
        SuspendLayout()
        ' 
        ' Rb1
        ' 
        Rb1.AutoSize = True
        Rb1.Location = New Point(6, 22)
        Rb1.Name = "Rb1"
        Rb1.Size = New Size(101, 19)
        Rb1.TabIndex = 0
        Rb1.TabStop = True
        Rb1.Text = "AVERAGE OF 3"
        Rb1.UseVisualStyleBackColor = True
        ' 
        ' Rb2
        ' 
        Rb2.AutoSize = True
        Rb2.Location = New Point(6, 47)
        Rb2.Name = "Rb2"
        Rb2.Size = New Size(101, 19)
        Rb2.TabIndex = 1
        Rb2.TabStop = True
        Rb2.Text = "AVERAGE OF 4"
        Rb2.UseVisualStyleBackColor = True
        ' 
        ' Rb3
        ' 
        Rb3.AutoSize = True
        Rb3.Location = New Point(6, 72)
        Rb3.Name = "Rb3"
        Rb3.Size = New Size(104, 19)
        Rb3.TabIndex = 2
        Rb3.TabStop = True
        Rb3.Text = "AVERAGE OF 5 "
        Rb3.UseVisualStyleBackColor = True
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(Rb2)
        GroupBox1.Controls.Add(Rb3)
        GroupBox1.Controls.Add(Rb1)
        GroupBox1.Location = New Point(12, 12)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(137, 100)
        GroupBox1.TabIndex = 3
        GroupBox1.TabStop = False
        GroupBox1.Text = "Number of numbers"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(265, 11)
        Label1.Name = "Label1"
        Label1.Size = New Size(0, 15)
        Label1.TabIndex = 4
        ' 
        ' Title1
        ' 
        Title1.AutoSize = True
        Title1.Location = New Point(268, 39)
        Title1.Name = "Title1"
        Title1.Size = New Size(35, 15)
        Title1.TabIndex = 5
        Title1.Text = "No.1 "
        ' 
        ' Title2
        ' 
        Title2.AutoSize = True
        Title2.Location = New Point(268, 68)
        Title2.Name = "Title2"
        Title2.Size = New Size(35, 15)
        Title2.TabIndex = 6
        Title2.Text = "No.2 "
        ' 
        ' title3
        ' 
        title3.AutoSize = True
        title3.Location = New Point(268, 97)
        title3.Name = "title3"
        title3.Size = New Size(32, 15)
        title3.TabIndex = 7
        title3.Text = "No.3"
        ' 
        ' title4
        ' 
        title4.AutoSize = True
        title4.Location = New Point(268, 121)
        title4.Name = "title4"
        title4.Size = New Size(35, 15)
        title4.TabIndex = 8
        title4.Text = "No.4 "
        ' 
        ' title5
        ' 
        title5.AutoSize = True
        title5.Location = New Point(268, 150)
        title5.Name = "title5"
        title5.Size = New Size(32, 15)
        title5.TabIndex = 9
        title5.Text = "No.5"
        ' 
        ' Num1
        ' 
        Num1.Location = New Point(306, 31)
        Num1.Name = "Num1"
        Num1.Size = New Size(100, 23)
        Num1.TabIndex = 10
        ' 
        ' Num2
        ' 
        Num2.Location = New Point(306, 60)
        Num2.Name = "Num2"
        Num2.Size = New Size(100, 23)
        Num2.TabIndex = 11
        ' 
        ' Num3
        ' 
        Num3.Location = New Point(306, 89)
        Num3.Name = "Num3"
        Num3.Size = New Size(100, 23)
        Num3.TabIndex = 12
        ' 
        ' Num4
        ' 
        Num4.Location = New Point(306, 118)
        Num4.Name = "Num4"
        Num4.Size = New Size(100, 23)
        Num4.TabIndex = 13
        ' 
        ' Num5
        ' 
        Num5.Location = New Point(306, 147)
        Num5.Name = "Num5"
        Num5.Size = New Size(100, 23)
        Num5.TabIndex = 14
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(138, 227)
        Label2.Name = "Label2"
        Label2.Size = New Size(162, 25)
        Label2.TabIndex = 16
        Label2.Text = "TOTAL AVERAGE : "
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(289, 324)
        Button1.Name = "Button1"
        Button1.Size = New Size(103, 38)
        Button1.TabIndex = 17
        Button1.Text = "Clear"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(162, 324)
        Button2.Name = "Button2"
        Button2.Size = New Size(103, 38)
        Button2.TabIndex = 18
        Button2.Text = "Solve"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(407, 324)
        Button3.Name = "Button3"
        Button3.Size = New Size(103, 38)
        Button3.TabIndex = 19
        Button3.Text = "Close"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 11F)
        Label3.Location = New Point(191, 287)
        Label3.Name = "Label3"
        Label3.Size = New Size(68, 20)
        Label3.TabIndex = 20
        Label3.Text = "GRADE : "
        ' 
        ' Grade
        ' 
        Grade.AutoSize = True
        Grade.Font = New Font("Segoe UI", 20F)
        Grade.Location = New Point(315, 273)
        Grade.Name = "Grade"
        Grade.Size = New Size(0, 37)
        Grade.TabIndex = 21
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(306, 230)
        Label4.Name = "Label4"
        Label4.Size = New Size(0, 21)
        Label4.TabIndex = 22
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Label4)
        Controls.Add(Grade)
        Controls.Add(Label3)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Label2)
        Controls.Add(Num5)
        Controls.Add(Num4)
        Controls.Add(Num3)
        Controls.Add(Num2)
        Controls.Add(Num1)
        Controls.Add(title5)
        Controls.Add(title4)
        Controls.Add(title3)
        Controls.Add(Title2)
        Controls.Add(Title1)
        Controls.Add(Label1)
        Controls.Add(GroupBox1)
        Name = "Form1"
        Text = "Form1"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Rb1 As RadioButton
    Friend WithEvents Rb2 As RadioButton
    Friend WithEvents Rb3 As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Title1 As Label
    Friend WithEvents Title2 As Label
    Friend WithEvents title3 As Label
    Friend WithEvents title4 As Label
    Friend WithEvents title5 As Label
    Friend WithEvents Num1 As TextBox
    Friend WithEvents Num2 As TextBox
    Friend WithEvents Num3 As TextBox
    Friend WithEvents Num4 As TextBox
    Friend WithEvents Num5 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Grade As Label
    Friend WithEvents Label4 As Label

End Class
