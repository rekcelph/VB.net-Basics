﻿Module Numbers
    Public numb1, numb2, numb3, numb4, numb5, Answer As Double
End Module
