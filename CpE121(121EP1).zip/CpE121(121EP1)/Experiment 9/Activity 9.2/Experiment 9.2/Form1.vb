﻿Imports System.Diagnostics.Eventing.Reader

Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Rb1_CheckedChanged(sender As Object, e As EventArgs) Handles Rb1.CheckedChanged
        If Rb1.Checked = True Then
            title4.Visible = False
            title5.Visible = False
            Num4.Visible = False
            Num5.Visible = False
        End If
    End Sub

    Private Sub Rb2_CheckedChanged(sender As Object, e As EventArgs) Handles Rb2.CheckedChanged
        If Rb2.Checked = True Then
            title4.Visible = True
            title5.Visible = False
            Num4.Visible = True
            Num5.Visible = False
        End If
    End Sub

    Private Sub Rb3_CheckedChanged(sender As Object, e As EventArgs) Handles Rb3.CheckedChanged
        If Rb3.Checked = True Then
            title4.Visible = True
            title5.Visible = True
            Num4.Visible = True
            Num5.Visible = True
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Rb1.Checked = True Then
            numb1 = Num1.Text
            numb2 = Num2.Text
            numb3 = Num3.Text

            Answer = (numb1 + numb2 + numb3) / 3
            Label4.Text = Answer
        End If

        If Rb2.Checked = True Then
            numb1 = Num1.Text
            numb2 = Num2.Text
            numb3 = Num3.Text
            numb4 = Num4.Text

            Answer = (numb1 + numb2 + numb3 + numb4) / 4
            Label4.Text = Answer
        End If

        If Rb3.Checked = True Then
            numb1 = Num1.Text
            numb2 = Num2.Text
            numb3 = Num3.Text
            numb4 = Num4.Text
            numb5 = Num5.Text

            Answer = (numb1 + numb2 + numb3 + numb4 + numb5) / 5
            Label4.Text = Answer
        End If

        If Answer >= 1 And Answer <= 75 = True Then
            Grade.Text = "F"

        ElseIf Answer >= 76 And Answer <= 80 = True Then
            Grade.Text = "D"
        ElseIf Answer >= 81 And Answer <= 85 = True Then
            Grade.Text = "C"
        ElseIf Answer >= 86 And Answer <= 90 = True Then
            Grade.Text = "B"
        ElseIf Answer >= 91 And Answer <= 95 = True Then
            Grade.Text = "A"

        ElseIf Answer > 96 And Answer <= 100 = True Then
            Grade.Text = "A+"
        ElseIf Answer <= 0 Then
            Grade.Text = " "

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Num1.Text = " "
        Num2.Text = " "
        Num3.Text = " "
        Num4.Text = " "
        Num5.Text = " "
        Label4.Text = " "
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Stop
    End Sub
End Class
