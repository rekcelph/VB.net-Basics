﻿Imports System.Security.AccessControl

Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GotoForm2.Visible = False




    End Sub

    Private Sub Enter1_Click(sender As Object, e As EventArgs) Handles Enter1.Click
        Fname1 = Fname.Text
        If CheckBox1.Checked = False Then
            CheckBox1.Checked = True


        End If



    End Sub

    Private Sub Enter2_Click(sender As Object, e As EventArgs) Handles Enter2.Click
        Lname1 = Lname.Text
        Enter2.Update()

        If CheckBox2.Checked = False Then
            CheckBox2.Checked = True
        End If




    End Sub

    Private Sub GotoForm2_Click(sender As Object, e As EventArgs) Handles GotoForm2.Click
        GotoForm2.Update()

        Page_2.ShowDialog()


    End Sub



    Private Overloads Sub Update(sender As Object, e As EventArgs) Handles CheckBox2.CheckStateChanged, CheckBox1.CheckStateChanged


        If CheckBox2.Checked = True And CheckBox1.Checked = True Then
            GotoForm2.Visible = True
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Stop
    End Sub
End Class
