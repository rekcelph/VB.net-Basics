﻿Public Class Page_2
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged


    End Sub

    Private Sub Page_2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Back1_Click(sender As Object, e As EventArgs) Handles Back1.Click
        Me.Hide()
        Form1.Show()
        Form1.CheckBox1.Checked = False
        Form1.CheckBox2.Checked = False
        Form1.Fname.Clear()
        Form1.Lname.Clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Fname1 = Form1.Fname.Text
        Lname1 = Form1.Lname.Text

        ListBox1.Items.Add("First Name : " & Fname1)
        ListBox1.Items.Add("Last Name : " & Lname1)

    End Sub
End Class