﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Title1 = New Label()
        Fname = New TextBox()
        Enter1 = New Button()
        Label2 = New Label()
        Lname = New TextBox()
        Enter2 = New Button()
        GotoForm2 = New Button()
        CheckBox1 = New CheckBox()
        CheckBox2 = New CheckBox()
        Button1 = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(316, 83)
        Label1.Name = "Label1"
        Label1.Size = New Size(103, 15)
        Label1.TabIndex = 0
        Label1.Text = "Enter First Name : "
        ' 
        ' Title1
        ' 
        Title1.AutoSize = True
        Title1.Location = New Point(304, 50)
        Title1.Name = "Title1"
        Title1.Size = New Size(127, 15)
        Title1.TabIndex = 1
        Title1.Text = "PLease Enter your Data"
        ' 
        ' Fname
        ' 
        Fname.Location = New Point(316, 101)
        Fname.Name = "Fname"
        Fname.Size = New Size(100, 23)
        Fname.TabIndex = 2
        ' 
        ' Enter1
        ' 
        Enter1.Location = New Point(325, 130)
        Enter1.Name = "Enter1"
        Enter1.Size = New Size(75, 23)
        Enter1.TabIndex = 3
        Enter1.Text = "SUBMIT"
        Enter1.UseVisualStyleBackColor = True
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(316, 168)
        Label2.Name = "Label2"
        Label2.Size = New Size(102, 15)
        Label2.TabIndex = 4
        Label2.Text = "Enter Last Name : "
        ' 
        ' Lname
        ' 
        Lname.Location = New Point(316, 186)
        Lname.Name = "Lname"
        Lname.Size = New Size(100, 23)
        Lname.TabIndex = 5
        ' 
        ' Enter2
        ' 
        Enter2.Location = New Point(325, 215)
        Enter2.Name = "Enter2"
        Enter2.Size = New Size(75, 23)
        Enter2.TabIndex = 6
        Enter2.Text = "SUBMIT "
        Enter2.UseVisualStyleBackColor = True
        ' 
        ' GotoForm2
        ' 
        GotoForm2.Location = New Point(325, 281)
        GotoForm2.Name = "GotoForm2"
        GotoForm2.Size = New Size(75, 23)
        GotoForm2.TabIndex = 7
        GotoForm2.Text = "Next"
        GotoForm2.UseVisualStyleBackColor = True
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Location = New Point(55, 83)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(83, 19)
        CheckBox1.TabIndex = 8
        CheckBox1.Text = "First Name"
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' CheckBox2
        ' 
        CheckBox2.AutoSize = True
        CheckBox2.Location = New Point(55, 108)
        CheckBox2.Name = "CheckBox2"
        CheckBox2.Size = New Size(82, 19)
        CheckBox2.TabIndex = 9
        CheckBox2.Text = "Last Name"
        CheckBox2.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(624, 32)
        Button1.Name = "Button1"
        Button1.Size = New Size(130, 23)
        Button1.TabIndex = 10
        Button1.Text = "CLOSE PROGRAM"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Button1)
        Controls.Add(CheckBox2)
        Controls.Add(CheckBox1)
        Controls.Add(GotoForm2)
        Controls.Add(Enter2)
        Controls.Add(Lname)
        Controls.Add(Label2)
        Controls.Add(Enter1)
        Controls.Add(Fname)
        Controls.Add(Title1)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Title1 As Label
    Friend WithEvents Fname As TextBox
    Friend WithEvents Enter1 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Lname As TextBox
    Friend WithEvents Enter2 As Button
    Friend WithEvents GotoForm2 As Button
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents Button1 As Button

End Class
