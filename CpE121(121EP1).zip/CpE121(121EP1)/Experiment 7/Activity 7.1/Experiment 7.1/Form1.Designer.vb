﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Add = New Button()
        Label1 = New Label()
        Label2 = New Label()
        FText = New TextBox()
        SText = New TextBox()
        Button2 = New Button()
        Button3 = New Button()
        Button4 = New Button()
        PictureBox1 = New PictureBox()
        Label3 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Add
        ' 
        Add.Location = New Point(73, 180)
        Add.Name = "Add"
        Add.Size = New Size(75, 23)
        Add.TabIndex = 0
        Add.Text = "Add"
        Add.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(73, 49)
        Label1.Name = "Label1"
        Label1.Size = New Size(82, 15)
        Label1.TabIndex = 1
        Label1.Text = "First Number: "
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(73, 99)
        Label2.Name = "Label2"
        Label2.Size = New Size(99, 15)
        Label2.TabIndex = 2
        Label2.Text = "Second Number: "
        ' 
        ' FText
        ' 
        FText.Location = New Point(161, 46)
        FText.Name = "FText"
        FText.Size = New Size(100, 23)
        FText.TabIndex = 3
        ' 
        ' SText
        ' 
        SText.Location = New Point(178, 99)
        SText.Name = "SText"
        SText.Size = New Size(100, 23)
        SText.TabIndex = 4
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(222, 180)
        Button2.Name = "Button2"
        Button2.Size = New Size(75, 23)
        Button2.TabIndex = 5
        Button2.Text = "MInus"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Button3
        ' 
        Button3.Location = New Point(73, 231)
        Button3.Name = "Button3"
        Button3.Size = New Size(75, 23)
        Button3.TabIndex = 6
        Button3.Text = "Multiply"
        Button3.UseVisualStyleBackColor = True
        ' 
        ' Button4
        ' 
        Button4.Location = New Point(222, 231)
        Button4.Name = "Button4"
        Button4.Size = New Size(75, 23)
        Button4.TabIndex = 7
        Button4.Text = "Divide"
        Button4.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources._418709331_1023915935371191_7431320030007204350_n
        PictureBox1.Location = New Point(469, 212)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(212, 159)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 8
        PictureBox1.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(469, 184)
        Label3.Name = "Label3"
        Label3.Size = New Size(120, 15)
        Label3.TabIndex = 9
        Label3.Text = "Sir ari akon calculator"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(255))
        ClientSize = New Size(800, 450)
        Controls.Add(Label3)
        Controls.Add(PictureBox1)
        Controls.Add(Button4)
        Controls.Add(Button3)
        Controls.Add(Button2)
        Controls.Add(SText)
        Controls.Add(FText)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(Add)
        Name = "Form1"
        Text = "Form1"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Add As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents FText As TextBox
    Friend WithEvents SText As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label3 As Label

End Class
