﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Add_Click(sender As Object, e As EventArgs) Handles Add.Click
        Dim Fnum As Integer = FText.Text
        Dim Snum As Integer = SText.Text
        Dim Tnum As Integer = Fnum + Snum

        MsgBox(Title:=("Addition"), Prompt:=("The Answer is: " & Tnum))
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim Fnum As Integer = FText.Text
        Dim Snum As Integer = SText.Text
        Dim Tnum As Double = Fnum / Snum

        MsgBox(Title:=("Addition"), Prompt:=("The Answer is: " & Tnum))
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Fnum As Integer = FText.Text
        Dim Snum As Integer = SText.Text
        Dim Tnum As Integer = Fnum - Snum

        MsgBox(Title:=("Addition"), Prompt:=("The Answer is: " & Tnum))
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim Fnum As Integer = FText.Text
        Dim Snum As Integer = SText.Text
        Dim Tnum As Integer = Fnum * Snum

        MsgBox(Title:=("Addition"), Prompt:=("The Answer is: " & Tnum))
    End Sub
End Class
