﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        RB_adjacent = New RadioButton()
        RB_Opposite = New RadioButton()
        RB_Hypotenuse = New RadioButton()
        txt_first = New TextBox()
        txt_second = New TextBox()
        txt_answer = New TextBox()
        lbl_a = New Label()
        lbl_b = New Label()
        lbl_c = New Label()
        lbl_first = New Label()
        lbl_second = New Label()
        btn_calculate = New Button()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' RB_adjacent
        ' 
        RB_adjacent.AutoSize = True
        RB_adjacent.Font = New Font("Nulshock Rg", 15F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        RB_adjacent.Location = New Point(10, 287)
        RB_adjacent.Name = "RB_adjacent"
        RB_adjacent.Size = New Size(203, 28)
        RB_adjacent.TabIndex = 0
        RB_adjacent.TabStop = True
        RB_adjacent.Text = "Adjacent (a)"
        RB_adjacent.UseVisualStyleBackColor = True
        ' 
        ' RB_Opposite
        ' 
        RB_Opposite.AutoSize = True
        RB_Opposite.Font = New Font("Nulshock Rg", 15F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        RB_Opposite.Location = New Point(10, 323)
        RB_Opposite.Name = "RB_Opposite"
        RB_Opposite.Size = New Size(194, 28)
        RB_Opposite.TabIndex = 1
        RB_Opposite.TabStop = True
        RB_Opposite.Text = "Opposite (b)"
        RB_Opposite.UseVisualStyleBackColor = True
        ' 
        ' RB_Hypotenuse
        ' 
        RB_Hypotenuse.AutoSize = True
        RB_Hypotenuse.Font = New Font("Nulshock Rg", 15F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        RB_Hypotenuse.Location = New Point(10, 357)
        RB_Hypotenuse.Name = "RB_Hypotenuse"
        RB_Hypotenuse.Size = New Size(237, 28)
        RB_Hypotenuse.TabIndex = 2
        RB_Hypotenuse.TabStop = True
        RB_Hypotenuse.Text = "Hypotenuse (c)"
        RB_Hypotenuse.UseVisualStyleBackColor = True
        ' 
        ' txt_first
        ' 
        txt_first.Location = New Point(387, 272)
        txt_first.Multiline = True
        txt_first.Name = "txt_first"
        txt_first.Size = New Size(67, 23)
        txt_first.TabIndex = 3
        ' 
        ' txt_second
        ' 
        txt_second.Location = New Point(583, 272)
        txt_second.Multiline = True
        txt_second.Name = "txt_second"
        txt_second.Size = New Size(67, 23)
        txt_second.TabIndex = 4
        ' 
        ' txt_answer
        ' 
        txt_answer.BackColor = SystemColors.InactiveCaption
        txt_answer.BorderStyle = BorderStyle.None
        txt_answer.Font = New Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        txt_answer.Location = New Point(426, 383)
        txt_answer.Multiline = True
        txt_answer.Name = "txt_answer"
        txt_answer.Size = New Size(379, 23)
        txt_answer.TabIndex = 5
        ' 
        ' lbl_a
        ' 
        lbl_a.AutoSize = True
        lbl_a.Font = New Font("Goudy Stout", 15F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lbl_a.Location = New Point(132, 231)
        lbl_a.Name = "lbl_a"
        lbl_a.Size = New Size(38, 27)
        lbl_a.TabIndex = 6
        lbl_a.Text = "a"
        ' 
        ' lbl_b
        ' 
        lbl_b.AutoSize = True
        lbl_b.Font = New Font("Goudy Stout", 15F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lbl_b.Location = New Point(-3, 93)
        lbl_b.Name = "lbl_b"
        lbl_b.Size = New Size(35, 27)
        lbl_b.TabIndex = 7
        lbl_b.Text = "b"
        ' 
        ' lbl_c
        ' 
        lbl_c.AutoSize = True
        lbl_c.Font = New Font("Goudy Stout", 15F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lbl_c.Location = New Point(312, 57)
        lbl_c.Name = "lbl_c"
        lbl_c.Size = New Size(33, 27)
        lbl_c.TabIndex = 8
        lbl_c.Text = "c"
        ' 
        ' lbl_first
        ' 
        lbl_first.AutoSize = True
        lbl_first.Font = New Font("Nulshock Rg", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lbl_first.Location = New Point(361, 299)
        lbl_first.Name = "lbl_first"
        lbl_first.Size = New Size(119, 16)
        lbl_first.TabIndex = 9
        lbl_first.Text = "Adjacent (a)"
        ' 
        ' lbl_second
        ' 
        lbl_second.AutoSize = True
        lbl_second.Font = New Font("Nulshock Rg", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lbl_second.Location = New Point(563, 299)
        lbl_second.Name = "lbl_second"
        lbl_second.Size = New Size(115, 16)
        lbl_second.TabIndex = 10
        lbl_second.Text = "Opposite (b)"
        ' 
        ' btn_calculate
        ' 
        btn_calculate.BackColor = Color.SkyBlue
        btn_calculate.Font = New Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btn_calculate.Location = New Point(475, 323)
        btn_calculate.Name = "btn_calculate"
        btn_calculate.Size = New Size(109, 48)
        btn_calculate.TabIndex = 11
        btn_calculate.Text = "Calculate"
        btn_calculate.UseVisualStyleBackColor = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = SystemColors.ButtonHighlight
        PictureBox1.BackgroundImageLayout = ImageLayout.None
        PictureBox1.Image = My.Resources.Resources.righttriDiv41
        PictureBox1.Location = New Point(32, 0)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(274, 228)
        PictureBox1.TabIndex = 12
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Nulshock Rg", 15.7499981F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(400, 44)
        Label1.Name = "Label1"
        Label1.Size = New Size(350, 25)
        Label1.TabIndex = 13
        Label1.Text = "PYTHAGOREAN THEOREM"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Nulshock Rg", 15F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(440, 103)
        Label2.Name = "Label2"
        Label2.Size = New Size(210, 24)
        Label2.TabIndex = 14
        Label2.Text = "c²   =   a²   +   b²"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Nulshock Rg", 15F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(440, 189)
        Label3.Name = "Label3"
        Label3.Size = New Size(204, 24)
        Label3.TabIndex = 15
        Label3.Text = "b²   =   c²   -   a²"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Nulshock Rg", 15F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(440, 149)
        Label4.Name = "Label4"
        Label4.Size = New Size(204, 24)
        Label4.TabIndex = 16
        Label4.Text = "a²   =   c²   -   b²"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Cooper Black", 15F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(301, 388)
        Label5.Name = "Label5"
        Label5.Size = New Size(119, 23)
        Label5.TabIndex = 17
        Label5.Text = "ANSWER :"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.InactiveCaption
        ClientSize = New Size(800, 450)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(PictureBox1)
        Controls.Add(btn_calculate)
        Controls.Add(lbl_second)
        Controls.Add(lbl_first)
        Controls.Add(lbl_c)
        Controls.Add(lbl_b)
        Controls.Add(lbl_a)
        Controls.Add(txt_answer)
        Controls.Add(txt_second)
        Controls.Add(txt_first)
        Controls.Add(RB_Hypotenuse)
        Controls.Add(RB_Opposite)
        Controls.Add(RB_adjacent)
        Name = "Form1"
        Text = "Form1"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents RB_adjacent As RadioButton
    Friend WithEvents RB_Opposite As RadioButton
    Friend WithEvents RB_Hypotenuse As RadioButton
    Friend WithEvents txt_first As TextBox
    Friend WithEvents txt_second As TextBox
    Friend WithEvents txt_answer As TextBox
    Friend WithEvents lbl_a As Label
    Friend WithEvents lbl_b As Label
    Friend WithEvents lbl_c As Label
    Friend WithEvents lbl_first As Label
    Friend WithEvents lbl_second As Label
    Friend WithEvents btn_calculate As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class
