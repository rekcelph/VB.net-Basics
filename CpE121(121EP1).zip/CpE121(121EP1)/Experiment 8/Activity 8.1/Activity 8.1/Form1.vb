﻿Imports System.Windows
Public Class Form1
    Dim a, b, c As Double

    Private Sub Form2_load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles btn_calculate.Click
        If RB_adjacent.Checked = True Then
            b = txt_first.Text
            c = txt_second.Text
            a = (c ^ 2 - b ^ 2) ^ 0.5
            txt_answer.Text = a
        ElseIf RB_Opposite.Checked = True Then
            a = txt_first.Text
            c = txt_second.Text
            b = (c ^ 2 - a ^ 2) ^ 0.5
            txt_answer.Text = b
        Else
            a = txt_first.Text
            b = txt_second.Text
            c = (a ^ 2 + b ^ 2) ^ 0.5

            txt_answer.Text = c
        End If

    End Sub

    Public Sub Update_Choice()
        If RB_adjacent.Checked = True Then

            lbl_a.ForeColor = Color.Red
            lbl_b.ForeColor = Color.Black
            lbl_c.ForeColor = Color.Black
            lbl_first.Text = "Opposite (b)"
            lbl_second.Text = "Hypotenuse (c)"

        ElseIf RB_Opposite.Checked = True Then

            lbl_a.ForeColor = Color.Black
            lbl_b.ForeColor = Color.Red
            lbl_c.ForeColor = Color.Black
            lbl_first.Text = "Adjacent (a)"
            lbl_second.Text = "Hypotenuse (c)"

        ElseIf RB_Hypotenuse.Checked = True Then

            lbl_a.ForeColor = Color.Black
            lbl_b.ForeColor = Color.Black
            lbl_c.ForeColor = Color.Red
            lbl_first.Text = "Adjacent(a)"
            lbl_second.Text = "Opposite (b) "

        Else
            lbl_a.ForeColor = Color.Black
            lbl_b.ForeColor = Color.Black
            lbl_c.ForeColor = Color.Black

        End If
    End Sub

    Private Sub RB_adjacent_CheckedChanged(sender As Object, e As EventArgs) Handles RB_adjacent.CheckedChanged

        txt_first.Text = " "
        txt_second.Text = " "
        txt_answer.Text = " "
        txt_first.Focus()
        Update_Choice()

    End Sub

    Private Sub RB_Opposite_CheckedChanged(sender As Object, e As EventArgs) Handles RB_Opposite.CheckedChanged

        txt_first.Text = " "
        txt_second.Text = " "
        txt_answer.Text = " "
        txt_first.Focus()
        Update_Choice()

    End Sub

    Private Sub RB_Hypotenuse_CheckedChanged(sender As Object, e As EventArgs) Handles RB_Hypotenuse.CheckedChanged

        txt_first.Text = " "
        txt_second.Text = " "
        txt_answer.Text = " "
        txt_first.Focus()
        Update_Choice()


    End Sub


End Class
