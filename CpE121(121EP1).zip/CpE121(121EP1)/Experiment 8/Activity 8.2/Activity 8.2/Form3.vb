﻿Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Hide()
        Dim f1 = New Form1
        f1.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2_2.Click
        Dim baseLength As Double
        Dim height As Double
        Dim decArea As Double

        If Double.TryParse(txt_first_2.Text, baseLength) AndAlso Double.TryParse(txt_second_2.Text, height) Then
            If baseLength > 0 AndAlso height > 0 Then
                decArea = 0.5 * baseLength * height
                Chuchu.Text = decArea.ToString()
            Else
                MessageBox.Show("Please enter valid base length and height values.")
            End If
        Else
            MessageBox.Show("Please enter valid base length and height values.")
        End If
    End Sub

End Class