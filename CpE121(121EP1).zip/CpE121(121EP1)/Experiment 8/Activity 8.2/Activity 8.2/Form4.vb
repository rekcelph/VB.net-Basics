﻿Public Class Form4
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Hide()
        Dim f4 = New Form1
        f4.Show()
    End Sub

    Private Sub Button2_4_Click(sender As Object, e As EventArgs) Handles Button2_4.Click
        Dim Length As Double
        Dim Width As Double
        Dim decArea As Double

        If Double.TryParse(txt_first_3.Text, Length) AndAlso Double.TryParse(txt_first_4.Text, Width) Then
            If Length > 0 AndAlso Height > 0 Then
                decArea = Width * Length
                Label4_4.Text = decArea.ToString()
            Else
                MessageBox.Show("Please enter valid base length and height values.")
            End If
        Else
            MessageBox.Show("Please enter valid base length and height values.")
        End If
    End Sub

End Class

