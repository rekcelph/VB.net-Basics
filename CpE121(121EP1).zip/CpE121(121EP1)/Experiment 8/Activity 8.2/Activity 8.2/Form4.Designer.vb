﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Button1 = New Button()
        Label1 = New Label()
        txt_first_3 = New TextBox()
        txt_first_4 = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        Button2_4 = New Button()
        Label4_4 = New Label()
        SuspendLayout()
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(630, 12)
        Button1.Name = "Button1"
        Button1.Size = New Size(131, 23)
        Button1.TabIndex = 0
        Button1.Text = "Main menu"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(12, 12)
        Label1.Name = "Label1"
        Label1.Size = New Size(62, 15)
        Label1.TabIndex = 1
        Label1.Text = "Rectangle "
        ' 
        ' txt_first_3
        ' 
        txt_first_3.Location = New Point(439, 135)
        txt_first_3.Name = "txt_first_3"
        txt_first_3.Size = New Size(100, 23)
        txt_first_3.TabIndex = 2
        ' 
        ' txt_first_4
        ' 
        txt_first_4.Location = New Point(439, 189)
        txt_first_4.Name = "txt_first_4"
        txt_first_4.Size = New Size(100, 23)
        txt_first_4.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(346, 143)
        Label2.Name = "Label2"
        Label2.Size = New Size(83, 15)
        Label2.TabIndex = 4
        Label2.Text = "Enter Length : "
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(351, 200)
        Label3.Name = "Label3"
        Label3.Size = New Size(78, 15)
        Label3.TabIndex = 5
        Label3.Text = "Enter Width : "
        ' 
        ' Button2_4
        ' 
        Button2_4.Location = New Point(432, 278)
        Button2_4.Name = "Button2_4"
        Button2_4.Size = New Size(75, 23)
        Button2_4.TabIndex = 6
        Button2_4.Text = "Calculate "
        Button2_4.UseVisualStyleBackColor = True
        ' 
        ' Label4_4
        ' 
        Label4_4.AutoSize = True
        Label4_4.Location = New Point(439, 248)
        Label4_4.Name = "Label4_4"
        Label4_4.Size = New Size(0, 15)
        Label4_4.TabIndex = 7
        ' 
        ' Form4
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(Label4_4)
        Controls.Add(Button2_4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(txt_first_4)
        Controls.Add(txt_first_3)
        Controls.Add(Label1)
        Controls.Add(Button1)
        Name = "Form4"
        Text = "Form4"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_first_3 As TextBox
    Friend WithEvents txt_first_4 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button2_4 As Button
    Friend WithEvents Label4_4 As Label
End Class
