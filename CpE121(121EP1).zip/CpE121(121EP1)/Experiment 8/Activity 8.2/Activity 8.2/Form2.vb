﻿Public Class Form2
    Dim diameter As Double
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Hide()
        Dim f1 = New Form1
        f1.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            diameter = CInt(txt_first.Text)
        Catch ex As Exception
            MessageBox.Show("Please enter a valid diameter.")
            Return
        End Try
        Dim decArea As Double = Math.PI * (diameter / 2) ^ 2

        Label3.Text = decArea.ToString()
    End Sub
End Class