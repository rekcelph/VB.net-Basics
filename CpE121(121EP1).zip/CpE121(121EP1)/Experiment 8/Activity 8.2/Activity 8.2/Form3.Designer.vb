﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Button1 = New Button()
        txt_first_2 = New TextBox()
        txt_second_2 = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        Button2_2 = New Button()
        Chuchu = New Label()
        PictureBox1 = New PictureBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(76, 38)
        Label1.Name = "Label1"
        Label1.Size = New Size(51, 15)
        Label1.TabIndex = 0
        Label1.Text = "Triangle "
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(674, 12)
        Button1.Name = "Button1"
        Button1.Size = New Size(114, 23)
        Button1.TabIndex = 1
        Button1.Text = "Main menu"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' txt_first_2
        ' 
        txt_first_2.Location = New Point(436, 153)
        txt_first_2.Name = "txt_first_2"
        txt_first_2.Size = New Size(100, 23)
        txt_first_2.TabIndex = 2
        ' 
        ' txt_second_2
        ' 
        txt_second_2.Location = New Point(436, 211)
        txt_second_2.Name = "txt_second_2"
        txt_second_2.Size = New Size(100, 23)
        txt_second_2.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(352, 161)
        Label2.Name = "Label2"
        Label2.Size = New Size(70, 15)
        Label2.TabIndex = 4
        Label2.Text = "Enter Base : "
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(352, 214)
        Label3.Name = "Label3"
        Label3.Size = New Size(82, 15)
        Label3.TabIndex = 5
        Label3.Text = "Enter Height : "
        ' 
        ' Button2_2
        ' 
        Button2_2.Location = New Point(424, 319)
        Button2_2.Name = "Button2_2"
        Button2_2.Size = New Size(75, 23)
        Button2_2.TabIndex = 6
        Button2_2.Text = "Calculate"
        Button2_2.UseVisualStyleBackColor = True
        ' 
        ' Chuchu
        ' 
        Chuchu.AutoSize = True
        Chuchu.Location = New Point(438, 271)
        Chuchu.Name = "Chuchu"
        Chuchu.Size = New Size(0, 15)
        Chuchu.TabIndex = 7
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.righttriDiv4
        PictureBox1.Location = New Point(31, 109)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(263, 245)
        PictureBox1.TabIndex = 8
        PictureBox1.TabStop = False
        ' 
        ' Form3
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(PictureBox1)
        Controls.Add(Chuchu)
        Controls.Add(Button2_2)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(txt_second_2)
        Controls.Add(txt_first_2)
        Controls.Add(Button1)
        Controls.Add(Label1)
        Name = "Form3"
        Text = "Form3"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents txt_first_2 As TextBox
    Friend WithEvents txt_second_2 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button2_2 As Button
    Friend WithEvents Chuchu As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
