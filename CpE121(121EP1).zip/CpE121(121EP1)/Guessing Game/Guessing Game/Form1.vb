﻿Public Class Form1
    Dim Secret_Number As Integer
    Dim Attempts As Integer
    Private Sub StartButton_Click(sender As Object, e As EventArgs) Handles StartButton.Click

        Randomize()

        Secret_Number = Int(Rnd() * 100)
        Attempts = 0
        LB_Guess.Items.Clear()
        LBAttempt.Text = ("Attempts : " & Attempts.ToString)
    End Sub

    Private Sub GuessANumberButton_Click(sender As Object, e As EventArgs) Handles GuessANumberButton.Click
        Dim MyNumber As Integer
        Dim Tmp As String

        Tmp = InputBox("Enter a number between 1 to 100 : Guessing Game")

        If IsNumeric(Tmp) Then
            MyNumber = Tmp
        Else
            MsgBox("Input numbers Only")
            Exit Sub
        End If

        If MyNumber = Secret_Number Then
            MsgBox("You Got it!!!")

        ElseIf MyNumber > Secret_Number Then
            LB_Guess.Items.Add("Taas Noy!!")
            MsgBox("Wrong Guess")
        ElseIf MyNumber < Secret_Number Then
            LB_Guess.Items.Add("Nubo Noy!!!")
            MsgBox("Wrong Guess")
        End If

        Attempts = Attempts + 1
        LBAttempt.Text = "Attemps : " & Attempts.ToString
    End Sub
End Class
