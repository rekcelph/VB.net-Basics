﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        StartButton = New Button()
        GuessANumberButton = New Button()
        LBAttempt = New Label()
        LB_Guess = New ListBox()
        SuspendLayout()
        ' 
        ' StartButton
        ' 
        StartButton.Location = New Point(88, 114)
        StartButton.Name = "StartButton"
        StartButton.Size = New Size(75, 23)
        StartButton.TabIndex = 0
        StartButton.Text = "START"
        StartButton.UseVisualStyleBackColor = True
        ' 
        ' GuessANumberButton
        ' 
        GuessANumberButton.Location = New Point(67, 223)
        GuessANumberButton.Name = "GuessANumberButton"
        GuessANumberButton.Size = New Size(121, 23)
        GuessANumberButton.TabIndex = 1
        GuessANumberButton.Text = "Guess a number"
        GuessANumberButton.UseVisualStyleBackColor = True
        ' 
        ' LBAttempt
        ' 
        LBAttempt.AutoSize = True
        LBAttempt.Location = New Point(88, 158)
        LBAttempt.Name = "LBAttempt"
        LBAttempt.Size = New Size(60, 15)
        LBAttempt.TabIndex = 2
        LBAttempt.Text = "Attempt : "
        ' 
        ' LB_Guess
        ' 
        LB_Guess.FormattingEnabled = True
        LB_Guess.ItemHeight = 15
        LB_Guess.Location = New Point(376, 140)
        LB_Guess.Name = "LB_Guess"
        LB_Guess.Size = New Size(120, 94)
        LB_Guess.TabIndex = 3
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(LB_Guess)
        Controls.Add(LBAttempt)
        Controls.Add(GuessANumberButton)
        Controls.Add(StartButton)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents StartButton As Button
    Friend WithEvents GuessANumberButton As Button
    Friend WithEvents LBAttempt As Label
    Friend WithEvents LB_Guess As ListBox

End Class
