#include <iostream>
#include <cmath>
using namespace std;

class pythagorean {
    private:
        double a, b, c;
    public:
        pythagorean(double a, double b, double c) : a(a), b(b), c(c) {}

        void calculateSides() {
            double A = atan2(b, a) * 180 / M_PI;
            double B = atan2(b, c) * 180 / M_PI;

            cout << "The lengths of the sides are: " << a << ", " << b << ", " << c << endl;
            cout << "The angles A and B are: " << A << " degrees, " << B << " degrees" << endl;
        }
};

int main() {
    double side1, side2, side3;

    cout << "Enter the lengths of the two sides of the right triangle: ";
    cin >> side1 >> side2;

    side3 = sqrt(side1 * side1 + side2 * side2);

    pythagorean Pytha(side1, side2, side3);
    Pytha.calculateSides();

    return 0;
}