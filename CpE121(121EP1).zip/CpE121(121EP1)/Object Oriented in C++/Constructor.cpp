#include <iostream>
using namespace std;

/*constructor in C++ is a special method that auotomatically called when
an object is created.
*/

// class Food 
// {
// public:
// Food()
// {
//     cout << "I love to eat" << endl;
// }
// };
// int main()
// {
//     Food Lobster;
//     return 0;
// }


class Food{
public:
string name;
string flavor;
int Kilo;

Food(string x, string y, int z) // parameters
{
    name = x;
    flavor = y;
    Kilo = z;
}
};
int main()
{
    Food Chips("KangkongChips","Sour & Spicy",250);
    Food Seafood("Garlic Butter Shrimp", "Buttered" ,20);
    
    //Chhips
    cout << "\nChips name: " << Chips.name << endl;
    cout << "Chips Flavor: "<< Chips.flavor<< endl;
    cout << "Chips Kilo: " << Chips.Kilo << endl;

    //SeaFood
    cout << "\nSeaFood name: " << Seafood.name << endl;
    cout << "SeaFood Flavor: "<< Seafood.flavor<< endl;
    cout << "Seafood Kilo: " << Seafood.Kilo << endl;
    return 0;
}