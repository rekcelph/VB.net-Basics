#include <iostream>
using namespace std;

class Employee{//The class 
public: //access modifier   //private
                            //public
                            //protected
                            //friend


    string Name;
    string Company;
    int Age;
    void IntroduceYourself(){
        cout<<"Name : " << Name << endl;
        cout<<"Company : "<< Company<< endl;
        cout<<"Age : " << Age<< endl;
    }
    Employee(string name, string company, int age){ //constructor
        Name = name;
        Company = company;
        Age = age;


    }
};
int main()
{
 int num;
 Employee employee1 = Employee("Aicel", "CelTech", 19); 
 /*employee1.Name = "Rekcel";
 employee1.Company = "Raitecth";
 employee1.Age = 19;*/
 employee1.IntroduceYourself(); 

 Employee employee2 = Employee("Aile", "Aitech", 19);
/*employee2.Name = "Aile";
employee2.Company = "Aitech";
employee2.Age = 19;*/
employee2.IntroduceYourself();

}

