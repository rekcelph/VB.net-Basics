#include <iostream>
using namespace std;

// class car
// {
// public:
// void BMW()
// {
//     cout <<"Expensive car" << endl;    //Inside method
// }
// };



class Car
{
public: 
void BMW();
};
void Car::BMW()
{
    cout <<"Expensive car" << endl; //outside method
}
int main()
{
    Car luxury;
    luxury.BMW();
    return 0;
}




// class Car {
//  public:
//  int speed (int x);

//  };
//  int Car :: speed (int x)   //outside method w/ parameters
//  {
//      return x;
//  }
//  int main()
//  {
//     int dasig;
//     Car Ferrari;
//     dasig = Ferrari.speed(1000);
//     cout <<"Ferrari speed" << dasig <<"MPH" <<  endl;
//     return 0;
//  }




// class car {
//     public:
//     int speed (int x)
//     {
//         return x;                    //inside method w/ parameters
//     }
// };
// int main()
// {
//     car Ferrari;
//     cout <<"Ferrari speed is " <<Ferrari.speed(1000)<<"MPH" << endl;
//     return 0;
// }





