#include <iostream>
using namespace std;

class CpE121
{
public:
    string name;
    int age;
    string status; 
    
};
int main()
{
    CpE121 student;
    CpE121 sit_in;

    student.name ="Rekcel";
    student.age = 18;
    student.status = "Single";

    cout << "name = " << student.name << endl;
    cout << "age = "  << student.age << endl;
    cout << "status = "<< student.status << endl;

    cin>>student.name;
    cin>>student.age;
    cin>>student.status;
    cout <<"name = " << sit_in.name << endl;
    cout << "status = " << sit_in.status<< endl;
    cout << "age = " << sit_in.age << endl;
    return 0;

}