#include <iostream>
using namespace std;

class Shape {
    private:
    double Base, Height;
    public:
    void setBase(int b) 
    { 
        Base = b;
    }
    double getBase() { return Base; }
    void setHeight(int h) { Height = h;}
    double getHeight() { return Height; }
    void calculateArea(char shape)
    {
        switch(shape)
        {
            case 'A':
            case 'a':
                cout << "Area of Rectangle: " << Base * Height << endl;
                break;
            case 'B':
            case 'b':
                cout << "Area of Square: " << Base * Base << endl;
                break;

            case 'C':
            case 'c':
                cout << "Area of Triangle: " << 5 * Base * Height << endl;
                break;
                
                default:
                cout << "Invalid choice." << endl;
        }
    }
};

int main()
{
    Shape s;
    char choice;
    double base, height;

    do
    {
    cout << "Choose the shape: "<< endl;
    cout << "A.Rectangle" << endl;
    cout << "B.Square" << endl;
    cout << "C.Triangle" << endl;
    cin >> choice;

    cout << "Enter the base: ";
    cin >> base;

    cout << "Enter the height: ";
    cin >> height;

    s.setBase(base);
    s.setHeight(height);

    s.calculateArea(choice);

    cout << "Would you like to continue? (Y/N): ";
    cin >> choice;
    } while (choice == 'Y'|| choice == 'y' );
    
    

    return 0;
}