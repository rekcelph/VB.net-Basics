#include <iostream>
#include <cmath>
#define PI 3.1415926
using namespace std;

class Right
{
private:
    double radius;
public:
//setter
    void setRadius(double volume, double height)
    {
        radius = sqrt((volume/PI) * height);
    }

//getter
    double getRadius()
    {
        return radius;
    }
};
int main()
{
    double volume, height;
    Right radius;
    cout << "Enter the Volume: ";
    cin >> volume;
    cout << "Enter the Height: ";
    cin >> height;
    radius.setRadius(volume,height);
    cout << "The base radius of the right cylinder is: " << radius.getRadius() << endl;
    return 0;
}