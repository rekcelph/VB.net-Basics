#include <iostream>
#include <iomanip>
#include <cmath>
#define PI 3.1415926535
using namespace std;

class Cylinder {
private:
 double radius;
 double height;
 double volume;

public: 
Cylinder(double r, double h) {
        setRadius(r);
        setHeight(h);
        setVolume(r, h);
    }

    void setRadius(double r) {radius = r;}

    double getRadius() {return radius;}

    void setHeight(double h) {height = h;}

    double getHeight() {return height;}

    void setVolume(double r, double h) {volume = r * r * h * PI;}

    double getVolume() {return volume;}

    void computeRadius() {setRadius(sqrt(getVolume() / (PI * getHeight() * getHeight())));}

    void displayRadius() {
        cout << "The radius of the right cylinder is: " << getRadius() << endl;
    }
};

int main()
{
    double volume;
    double height;

    cout << "Enter the volume of the right cylinder: "<< endl;
    cin >> volume;

    cout << "Enter the height of the right cylinder: " << endl;
    cin >> height;

    Cylinder cylinder(sqrt(volume / (PI * height * height)), height);
    cylinder.computeRadius();
    cylinder.displayRadius();

    return 0;
}