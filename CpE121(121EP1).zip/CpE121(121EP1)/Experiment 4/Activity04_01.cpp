#include <iostream>
//Create a C++ program that will compute the average of five numbers. Create a private
//and public methods in your program to practice encapsulation. Use get and set method.
using namespace std;

class average {
    private:
    double num1, num2, num3, num4, num5;

    public:
    //setter
    void setnumber(int num_1,int num_2, int num_3,int num_4,int num_5) { 
        num1 = num_1; 
        num2 = num_2;
        num3 = num_3;
        num4 = num_4;
        num5 = num_5;
    }
    //getter
    int getAverage() { 
        return  (num1+num2+num3+num4+num5)/5 ;
    }
    
};
int main()
{
    average obj;
    double num_1, num_2, num_3, num_4, num_5; 
     
    cout << "Enter five numbers " << endl;
    cout << "Enter number 1: ";
    cin >> num_1;
    cout << "Enter number 2: ";
    cin >> num_2;
    cout << "Enter number 3: ";
    cin >> num_3;
    cout << "Enter number 4: ";
    cin >> num_4;
    cout << "Enter number 5: ";
    cin >> num_5;
    obj.setnumber(num_1,num_2,num_3,num_4,num_5);
    
    cout << "Average: " << obj.getAverage() << endl; 
    
    return 0;
}