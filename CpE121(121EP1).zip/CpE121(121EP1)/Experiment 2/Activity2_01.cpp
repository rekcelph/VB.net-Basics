#include <iostream>
#include <string>
using namespace std;

class Animal
{
    public:
    void Cow();
    void Dog();
    void Bird();
    void Cat();
};
    void Animal::Cow()
    {
        cout << "MOOO!!!!" << endl;
    }
    void Animal::Dog()
    {
        cout << "WOF WOF WOF" << endl;
    }
    void Animal::Bird()
    {
        cout << "TWIT TWIT" << endl;
    }
    void Animal::Cat()
    {
        cout << "Meow Meow" << endl;
    }

int main()
{

    int choice;
    Animal Callout;
    cout << "Choose your animal: " << endl;
    cout << "1. Cow" << endl;
    cout << "2. Dog" << endl;
    cout << "3. Bird" << endl;
    cout << "4. Cat" << endl;
    cin >> choice;

    switch (choice)
    {
    case 1:
        Callout.Cow();
        break;
    case 2:
        Callout.Dog();
        break;
    case 3:
        Callout.Bird();
        break;
    case 4:
        Callout.Cat();
        break;
    default:
        cout << "Invalid choice." << endl;
        return 0;
    }



    return 0;
}

