#include <iostream>
#include <string>
using namespace std;

class Person {
public:
    string Name;
    int Age;
    string ContactNumber;

    void displayInformation(string choice) {
        cout << choice << "'s Info:" << endl;
        cout << "Name: " << Name << endl;
        cout << "Contact No. : " << ContactNumber << endl;
        cout << "Age: " << Age << " years old" << endl;
    }
};

int main() {
    char choice;
    cout << "Press 'S' if you are a student and 'E' if you are an Employee: ";
    cin >> choice;
    cin.ignore();


    if (choice == 'S' || choice == 's') {
        Person student;
        
        cout << "Enter Student Name: ";
        getline(cin, student.Name);

        cout << "Enter Student Contact No.: ";
        getline(cin, student.ContactNumber);

        cout << "Enter Student Age: ";
        cin >> student.Age;

        student.displayInformation("Student");
    } else if (choice == 'E' || choice == 'e') {
        Person employee;
        
        cout << "Enter Employee Name: ";
        getline(cin, employee.Name);

        cout << "Enter Employee Contact No.: ";
        getline(cin, employee.ContactNumber);

        cout << "Enter Employee Age: ";
        cin >> employee.Age;

        employee.displayInformation("Employee");
    } else {
        cout << "Invalid input." << endl;
    }

    return 0;
}

