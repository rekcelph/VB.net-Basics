﻿Module Variable
    Public fname, mname, lname As String
End Module
