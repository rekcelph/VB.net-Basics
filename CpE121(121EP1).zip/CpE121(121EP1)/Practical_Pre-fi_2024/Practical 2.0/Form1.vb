﻿Public Class Form1
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If TextBox1.Text = "" And TextBox2.Text = "" Then
            Label1.Text = " "
        End If
        GB1.Visible = False
        GB3.Visible = False
        GB4.Visible = False

        Label1.Update()

    End Sub

    Private Sub Update(sender As Object, e As EventArgs) Handles TextBox1.TextChanged, TextBox2.TextChanged, TextBox3.TextChanged
        Dim numb1, numb2, numb3, answer As Double
        numb1 = Val(TextBox1.Text)
        numb2 = Val(TextBox2.Text)
        numb3 = Val(TextBox3.Text)
        answer = (numb1 + numb2 + numb3) / 3


        Label1.Text = answer

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Label1.Text = " "
        TextBox1.Text = " "
        TextBox2.Text = " "
    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            GB1.Visible = True
            CheckBox3.Checked = False
            CheckBox4.Checked = False
        Else
            GB1.Visible = False
        End If
    End Sub


    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            GB3.Visible = True
            CheckBox2.Checked = False
            CheckBox4.Checked = False
        Else
            GB3.Visible = False
        End If
    End Sub

    Private Sub CheckBox4_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox4.CheckedChanged
        If CheckBox4.Checked = True Then
            GB4.Visible = True
            CheckBox2.Checked = False
            CheckBox3.Checked = False
        Else
            GB4.Visible = False
        End If
    End Sub
    Private Sub LastName_CheckedChanged(sender As Object, e As EventArgs) Handles LastName.CheckedChanged
        If LastName.Checked = True Then
            FirstName.Checked = False
            PseudoName.Checked = False
            FullName.Checked = False
            Display.Text = "ENDENCIA"
        End If
    End Sub

    Private Sub FirstName_CheckedChanged(sender As Object, e As EventArgs) Handles FirstName.CheckedChanged
        If FirstName.Checked = True Then
            LastName.Checked = False
            PseudoName.Checked = False
            FullName.Checked = False
            Display.Text = "REKCEL"

        End If
    End Sub

    Private Sub PseudoName_CheckedChanged(sender As Object, e As EventArgs) Handles PseudoName.CheckedChanged
        If PseudoName.Checked = True Then
            FirstName.Checked = False
            LastName.Checked = False
            FullName.Checked = False
            Display.Text = "REKCEL GWAPO"
        End If
    End Sub

    Private Sub FullName_CheckedChanged(sender As Object, e As EventArgs) Handles FullName.CheckedChanged
        If FullName.Checked = True Then
            PseudoName.Checked = False
            FirstName.Checked = False
            LastName.Checked = False
            Display.Text = "REKCEL M. ENDENCIA"
        End If
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        Dim answer As Double
        Dim mm As Double
        mm = Val(TB4.Text)
        Dim cm As Double = mm / 10
        answer = cm
        Converted.Text = "Converted value: " & answer.ToString() & " cm"
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        Dim answer As Double
        Dim cm As Double
        cm = Val(TB4.Text)
        Dim dm As Double = cm / 10
        answer = dm
        Converted.Text = "Converted value: " & answer.ToString() & " dm"
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        Dim answer As Double
        Dim dm As Double
        dm = Val(TB4.Text)
        Dim m As Double = dm / 10
        answer = m
        Converted.Text = "Converted value: " & answer.ToString() & " m"
    End Sub

    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        Dim answer As Double
        Dim m As Double
        m = Val(TB4.Text)
        Dim km As Double = m / 1000
        answer = km
        Converted.Text = "Converted value: " & answer.ToString() & " km"
    End Sub

    Private Sub RadioButton5_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton5.CheckedChanged
        Dim answer As Double
        Dim cm As Double
        cm = Val(TB4.Text)
        Dim mm As Double = cm * 10
        answer = mm
        Converted.Text = "Converted value: " & answer.ToString() & " mm"
    End Sub

    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton6.CheckedChanged
        Dim answer As Double
        Dim dm As Double
        dm = Val(TB4.Text)
        Dim cm As Double = dm * 10
        answer = cm
        Converted.Text = "Converted value: " & answer.ToString() & " cm"
    End Sub

    Private Sub RadioButton7_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton7.CheckedChanged
        Dim answer As Double
        Dim m As Double
        m = Val(TB4.Text)
        Dim dm As Double = m * 10
        answer = dm
        Converted.Text = "Converted value: " & answer.ToString() & " dm"
    End Sub

    Private Sub RadioButton8_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton8.CheckedChanged
        Dim answer As Double
        Dim km As Double
        km = Val(TB4.Text)
        Dim m As Double = km * 1000
        answer = m
        Converted.Text = "Converted value: " & answer.ToString() & " m"
    End Sub

End Class