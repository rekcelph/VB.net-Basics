﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        GB1 = New GroupBox()
        Label8 = New Label()
        Label5 = New Label()
        TextBox3 = New TextBox()
        CheckBox2 = New CheckBox()
        CheckBox3 = New CheckBox()
        CheckBox4 = New CheckBox()
        GroupBox2 = New GroupBox()
        GB3 = New GroupBox()
        Display = New Label()
        GB4 = New GroupBox()
        Label7 = New Label()
        Converted = New Label()
        Label6 = New Label()
        TB4 = New TextBox()
        RadioButton8 = New RadioButton()
        RadioButton7 = New RadioButton()
        RadioButton6 = New RadioButton()
        RadioButton5 = New RadioButton()
        RadioButton4 = New RadioButton()
        RadioButton3 = New RadioButton()
        RadioButton2 = New RadioButton()
        RadioButton1 = New RadioButton()
        FullName = New CheckBox()
        PseudoName = New CheckBox()
        FirstName = New CheckBox()
        LastName = New CheckBox()
        Label4 = New Label()
        GB1.SuspendLayout()
        GroupBox2.SuspendLayout()
        GB3.SuspendLayout()
        GB4.SuspendLayout()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Stencil", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(243, 78)
        Label1.Name = "Label1"
        Label1.Size = New Size(0, 18)
        Label1.TabIndex = 0
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(22, 33)
        Label2.Name = "Label2"
        Label2.Size = New Size(46, 19)
        Label2.TabIndex = 1
        Label2.Text = "Num1 :"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(22, 82)
        Label3.Name = "Label3"
        Label3.Size = New Size(46, 19)
        Label3.TabIndex = 2
        Label3.Text = "Num2 :"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(66, 30)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(100, 26)
        TextBox1.TabIndex = 3
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(66, 75)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(100, 26)
        TextBox2.TabIndex = 4
        ' 
        ' GB1
        ' 
        GB1.BackColor = SystemColors.ButtonHighlight
        GB1.Controls.Add(Label8)
        GB1.Controls.Add(Label5)
        GB1.Controls.Add(TextBox3)
        GB1.Controls.Add(TextBox1)
        GB1.Controls.Add(TextBox2)
        GB1.Controls.Add(Label2)
        GB1.Controls.Add(Label1)
        GB1.Controls.Add(Label3)
        GB1.Font = New Font("Rockwell Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        GB1.Location = New Point(258, 89)
        GB1.Name = "GB1"
        GB1.Size = New Size(438, 191)
        GB1.TabIndex = 6
        GB1.TabStop = False
        GB1.Text = "Calculate"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(187, 78)
        Label8.Name = "Label8"
        Label8.Size = New Size(50, 19)
        Label8.TabIndex = 7
        Label8.Text = "Output :"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(22, 132)
        Label5.Name = "Label5"
        Label5.Size = New Size(46, 19)
        Label5.TabIndex = 6
        Label5.Text = "Num3 :"
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(66, 126)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(100, 26)
        TextBox3.TabIndex = 5
        ' 
        ' CheckBox2
        ' 
        CheckBox2.AutoSize = True
        CheckBox2.Location = New Point(6, 42)
        CheckBox2.Name = "CheckBox2"
        CheckBox2.Size = New Size(223, 23)
        CheckBox2.TabIndex = 7
        CheckBox2.Text = "Calculate Average of 3"
        CheckBox2.UseVisualStyleBackColor = True
        ' 
        ' CheckBox3
        ' 
        CheckBox3.AutoSize = True
        CheckBox3.Location = New Point(6, 129)
        CheckBox3.Name = "CheckBox3"
        CheckBox3.Size = New Size(71, 23)
        CheckBox3.TabIndex = 8
        CheckBox3.Text = "Name"
        CheckBox3.UseVisualStyleBackColor = True
        ' 
        ' CheckBox4
        ' 
        CheckBox4.AutoSize = True
        CheckBox4.Location = New Point(6, 88)
        CheckBox4.Name = "CheckBox4"
        CheckBox4.Size = New Size(133, 23)
        CheckBox4.TabIndex = 9
        CheckBox4.Text = "Conversions"
        CheckBox4.UseVisualStyleBackColor = True
        ' 
        ' GroupBox2
        ' 
        GroupBox2.BackColor = SystemColors.ButtonFace
        GroupBox2.BackgroundImageLayout = ImageLayout.None
        GroupBox2.Controls.Add(GB3)
        GroupBox2.Controls.Add(GB4)
        GroupBox2.Controls.Add(CheckBox2)
        GroupBox2.Controls.Add(GB1)
        GroupBox2.Controls.Add(CheckBox4)
        GroupBox2.Controls.Add(CheckBox3)
        GroupBox2.Font = New Font("Stencil", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        GroupBox2.Location = New Point(12, 12)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(863, 426)
        GroupBox2.TabIndex = 10
        GroupBox2.TabStop = False
        GroupBox2.Text = "Please Select an Option :"
        ' 
        ' GB3
        ' 
        GB3.BackColor = SystemColors.ButtonHighlight
        GB3.Controls.Add(Display)
        GB3.Controls.Add(FullName)
        GB3.Controls.Add(PseudoName)
        GB3.Controls.Add(FirstName)
        GB3.Controls.Add(LastName)
        GB3.Controls.Add(Label4)
        GB3.Font = New Font("Rockwell", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        GB3.Location = New Point(258, 87)
        GB3.Name = "GB3"
        GB3.Size = New Size(525, 187)
        GB3.TabIndex = 11
        GB3.TabStop = False
        ' 
        ' Display
        ' 
        Display.AutoSize = True
        Display.Font = New Font("Stencil", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Display.Location = New Point(173, 78)
        Display.Name = "Display"
        Display.Size = New Size(0, 32)
        Display.TabIndex = 5
        ' 
        ' GB4
        ' 
        GB4.BackColor = SystemColors.ButtonHighlight
        GB4.Controls.Add(Label7)
        GB4.Controls.Add(Converted)
        GB4.Controls.Add(Label6)
        GB4.Controls.Add(TB4)
        GB4.Controls.Add(RadioButton8)
        GB4.Controls.Add(RadioButton7)
        GB4.Controls.Add(RadioButton6)
        GB4.Controls.Add(RadioButton5)
        GB4.Controls.Add(RadioButton4)
        GB4.Controls.Add(RadioButton3)
        GB4.Controls.Add(RadioButton2)
        GB4.Controls.Add(RadioButton1)
        GB4.Font = New Font("Rockwell Condensed", 12F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        GB4.Location = New Point(346, 60)
        GB4.Name = "GB4"
        GB4.Size = New Size(325, 253)
        GB4.TabIndex = 12
        GB4.TabStop = False
        GB4.Text = "Conversion "
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(15, 69)
        Label7.Name = "Label7"
        Label7.Size = New Size(191, 19)
        Label7.TabIndex = 11
        Label7.Text = "Choose a unit you want to convert"
        ' 
        ' Converted
        ' 
        Converted.AutoSize = True
        Converted.Location = New Point(61, 211)
        Converted.Name = "Converted"
        Converted.Size = New Size(0, 19)
        Converted.TabIndex = 10
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(14, 43)
        Label6.Name = "Label6"
        Label6.Size = New Size(101, 19)
        Label6.TabIndex = 9
        Label6.Text = "Enter a number : "
        ' 
        ' TB4
        ' 
        TB4.Location = New Point(113, 40)
        TB4.Name = "TB4"
        TB4.Size = New Size(100, 26)
        TB4.TabIndex = 8
        ' 
        ' RadioButton8
        ' 
        RadioButton8.AutoSize = True
        RadioButton8.Location = New Point(165, 177)
        RadioButton8.Name = "RadioButton8"
        RadioButton8.Size = New Size(65, 23)
        RadioButton8.TabIndex = 7
        RadioButton8.TabStop = True
        RadioButton8.Text = "km - m"
        RadioButton8.UseVisualStyleBackColor = True
        ' 
        ' RadioButton7
        ' 
        RadioButton7.AutoSize = True
        RadioButton7.Location = New Point(165, 152)
        RadioButton7.Name = "RadioButton7"
        RadioButton7.Size = New Size(70, 23)
        RadioButton7.TabIndex = 6
        RadioButton7.TabStop = True
        RadioButton7.Text = "m - dm "
        RadioButton7.UseVisualStyleBackColor = True
        ' 
        ' RadioButton6
        ' 
        RadioButton6.AutoSize = True
        RadioButton6.Location = New Point(165, 127)
        RadioButton6.Name = "RadioButton6"
        RadioButton6.Size = New Size(76, 23)
        RadioButton6.TabIndex = 5
        RadioButton6.TabStop = True
        RadioButton6.Text = "dm - cm "
        RadioButton6.UseVisualStyleBackColor = True
        ' 
        ' RadioButton5
        ' 
        RadioButton5.AutoSize = True
        RadioButton5.Location = New Point(165, 105)
        RadioButton5.Name = "RadioButton5"
        RadioButton5.Size = New Size(79, 23)
        RadioButton5.TabIndex = 4
        RadioButton5.TabStop = True
        RadioButton5.Text = "cm - mm "
        RadioButton5.UseVisualStyleBackColor = True
        ' 
        ' RadioButton4
        ' 
        RadioButton4.AutoSize = True
        RadioButton4.Location = New Point(27, 177)
        RadioButton4.Name = "RadioButton4"
        RadioButton4.Size = New Size(65, 23)
        RadioButton4.TabIndex = 3
        RadioButton4.TabStop = True
        RadioButton4.Text = "m - km"
        RadioButton4.UseVisualStyleBackColor = True
        ' 
        ' RadioButton3
        ' 
        RadioButton3.AutoSize = True
        RadioButton3.Location = New Point(27, 152)
        RadioButton3.Name = "RadioButton3"
        RadioButton3.Size = New Size(65, 23)
        RadioButton3.TabIndex = 2
        RadioButton3.TabStop = True
        RadioButton3.Text = "dm - m"
        RadioButton3.UseVisualStyleBackColor = True
        ' 
        ' RadioButton2
        ' 
        RadioButton2.AutoSize = True
        RadioButton2.Location = New Point(27, 127)
        RadioButton2.Name = "RadioButton2"
        RadioButton2.Size = New Size(71, 23)
        RadioButton2.TabIndex = 1
        RadioButton2.TabStop = True
        RadioButton2.Text = "cm - dm"
        RadioButton2.UseVisualStyleBackColor = True
        ' 
        ' RadioButton1
        ' 
        RadioButton1.AutoSize = True
        RadioButton1.Location = New Point(27, 102)
        RadioButton1.Name = "RadioButton1"
        RadioButton1.Size = New Size(74, 23)
        RadioButton1.TabIndex = 0
        RadioButton1.TabStop = True
        RadioButton1.Text = "mm - cm"
        RadioButton1.UseVisualStyleBackColor = True
        ' 
        ' FullName
        ' 
        FullName.AutoSize = True
        FullName.Location = New Point(20, 138)
        FullName.Name = "FullName"
        FullName.Size = New Size(107, 23)
        FullName.TabIndex = 4
        FullName.Text = "FullName"
        FullName.UseVisualStyleBackColor = True
        ' 
        ' PseudoName
        ' 
        PseudoName.AutoSize = True
        PseudoName.Location = New Point(20, 109)
        PseudoName.Name = "PseudoName"
        PseudoName.Size = New Size(132, 23)
        PseudoName.TabIndex = 3
        PseudoName.Text = "PseudoName"
        PseudoName.UseVisualStyleBackColor = True
        ' 
        ' FirstName
        ' 
        FirstName.AutoSize = True
        FirstName.Location = New Point(20, 80)
        FirstName.Name = "FirstName"
        FirstName.Size = New Size(112, 23)
        FirstName.TabIndex = 2
        FirstName.Text = "FirstName"
        FirstName.UseVisualStyleBackColor = True
        ' 
        ' LastName
        ' 
        LastName.AutoSize = True
        LastName.Location = New Point(20, 50)
        LastName.Name = "LastName"
        LastName.Size = New Size(112, 23)
        LastName.TabIndex = 1
        LastName.Text = "LastName "
        LastName.UseVisualStyleBackColor = True
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(20, 8)
        Label4.Name = "Label4"
        Label4.Size = New Size(443, 19)
        Label4.TabIndex = 0
        Label4.Text = "What would you like to display about the Programmer?"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ButtonHighlight
        ClientSize = New Size(887, 450)
        Controls.Add(GroupBox2)
        Name = "Form1"
        GB1.ResumeLayout(False)
        GB1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        GB3.ResumeLayout(False)
        GB3.PerformLayout()
        GB4.ResumeLayout(False)
        GB4.PerformLayout()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GB1 As GroupBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GB3 As GroupBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents FullName As CheckBox
    Friend WithEvents PseudoName As CheckBox
    Friend WithEvents FirstName As CheckBox
    Friend WithEvents LastName As CheckBox
    Friend WithEvents Display As Label
    Friend WithEvents GB4 As GroupBox
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents RadioButton8 As RadioButton
    Friend WithEvents RadioButton7 As RadioButton
    Friend WithEvents RadioButton6 As RadioButton
    Friend WithEvents RadioButton5 As RadioButton
    Friend WithEvents Label6 As Label
    Friend WithEvents TB4 As TextBox
    Friend WithEvents Converted As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label

End Class
