﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim filename As String = "C:\Users\Rekcel M. Endencia\Desktop\test2.txt"
        If System.IO.File.Exists(filename) = True Then
            Dim fileholder As New System.IO.StreamWriter(filename)
            fileholder.Write(TextBox1.Text)
            fileholder.Close()
            MsgBox("Text written to file")

        Else
            MsgBox("File doesnt exist")
        End If
    End Sub
End Class
